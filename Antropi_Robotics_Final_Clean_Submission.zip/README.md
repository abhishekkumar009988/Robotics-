# TurtleBot3 Nav2 Demo

This is my assignment for the Robotics Software Intern role.

I used TurtleBot3 in Gazebo with ROS 2 Nav2. The goal is given from RViz and the robot moves to that point while avoiding obstacles.

## Setup

I used Ubuntu 24.04 and ROS 2 Jazzy.

Install the required packages:

```bash
sudo apt update
sudo apt install ros-jazzy-navigation2 ros-jazzy-nav2-bringup 'ros-jazzy-nav2-minimal-tb*'
```

Source ROS:

```bash
source /opt/ros/jazzy/setup.bash
```

Create a workspace and put this folder inside `src`:

```bash
mkdir -p ~/nav2_ws/src
cd ~/nav2_ws
colcon build --symlink-install
source install/setup.bash
```

Run:

```bash
ros2 launch turtlebot3_nav2_demo demo.launch.py
```

After Gazebo and RViz open:

1. Set the robot position using **2D Pose Estimate**.
2. Click **Nav2 Goal**.
3. Select a goal point on the map.
4. The robot should plan a path and move to the goal.

## Demo

In my demo I show the TurtleBot3 moving in Gazebo and the path in RViz.
