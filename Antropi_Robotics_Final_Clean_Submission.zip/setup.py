from setuptools import find_packages, setup
from glob import glob
import os

package_name = 'turtlebot3_nav2_demo'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
         glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Abhishek Kumar',
    maintainer_email='abhishekkumar0052001@gmail.com',
    description='TurtleBot3 Nav2 demo',
    license='MIT',
)
